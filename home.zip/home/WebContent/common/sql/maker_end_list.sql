create table maker_end_list (
	id int primary key,
	end_value varchar(100) not null
);

select * from maker_end_list;

insert into maker_end_list (id, end_value) values (1, '勇者');

insert into maker_end_list (id, end_value) values (2, '姫');

insert into maker_end_list (id, end_value) values (3, '魔王');

insert into maker_end_list (id, end_value) values (4, '王様');

insert into maker_end_list (id, end_value) values (5, '騎士');

insert into maker_end_list (id, end_value) values (6, '村人');

insert into maker_end_list (id, end_value) values (7, '商人');

insert into maker_end_list (id, end_value) values (8, 'スライム');

insert into maker_end_list (id, end_value) values (9, 'ゴブリン');

insert into maker_end_list (id, end_value) values (10, 'さだまさし');

insert into maker_end_list (id, end_value) values (11, 'エルフ');

insert into maker_end_list (id, end_value) values (12, 'ドワーフ');

insert into maker_end_list (id, end_value) values (13, '神');

insert into maker_end_list (id, end_value) values (14, '盗賊');

insert into maker_end_list (id, end_value) values (15, '大臣');

insert into maker_end_list (id, end_value) values (16, 'オーク');

insert into maker_end_list (id, end_value) values (17, 'ドラゴン');

insert into maker_end_list (id, end_value) values (18, '兵士');

insert into maker_end_list (id, end_value) values (19, '神父');

insert into maker_end_list (id, end_value) values (20, 'シスター');

insert into maker_end_list (id, end_value) values (21, '戦士');

insert into maker_end_list (id, end_value) values (22, '魔法使い');

insert into maker_end_list (id, end_value) values (23, '僧侶');

insert into maker_end_list (id, end_value) values (24, '貴族');

insert into maker_end_list (id, end_value) values (25, '王子');

insert into maker_end_list (id, end_value) values (26, '賢者');

insert into maker_end_list (id, end_value) values (27, '剣士');

insert into maker_end_list (id, end_value) values (28, '犬');

insert into maker_end_list (id, end_value) values (29, '猫');

insert into maker_end_list (id, end_value) values (30, '馬');

insert into maker_end_list (id, end_value) values (31, '獣人');

insert into maker_end_list (id, end_value) values (32, '牛');

insert into maker_end_list (id, end_value) values (33, '部長');

insert into maker_end_list (id, end_value) values (34, 'ゴーレム');

insert into maker_end_list (id, end_value) values (35, '長老');

insert into maker_end_list (id, end_value) values (36, '総理大臣');

insert into maker_end_list (id, end_value) values (37, '大統領');

insert into maker_end_list (id, end_value) values (38, '天使');

insert into maker_end_list (id, end_value) values (39, '悪魔');

insert into maker_end_list (id, end_value) values (40, '侍');

insert into maker_end_list (id, end_value) values (41, '料理人');

insert into maker_end_list (id, end_value) values (42, '執事');

insert into maker_end_list (id, end_value) values (43, 'メイド');

insert into maker_end_list (id, end_value) values (44, 'インストラクター');

insert into maker_end_list (id, end_value) values (45, 'お爺ちゃん');

insert into maker_end_list (id, end_value) values (46, 'お婆ちゃん');

insert into maker_end_list (id, end_value) values (47, '武闘家');

insert into maker_end_list (id, end_value) values (48, '殿様');

insert into maker_end_list (id, end_value) values (49, '王妃');

insert into maker_end_list (id, end_value) values (50, '西川貴教');