create table maker_start_list (
	id int primary key,
	start_value varchar(100) not null
);

select * from maker_start_list;

insert into maker_start_list (id, start_value) values (1, '普通の');

insert into maker_start_list (id, start_value) values (2, '勇敢な');

insert into maker_start_list (id, start_value) values (3, '気弱な');

insert into maker_start_list (id, start_value) values (4, '正義の');

insert into maker_start_list (id, start_value) values (5, '悪の');

insert into maker_start_list (id, start_value) values (6, 'やさしい');

insert into maker_start_list (id, start_value) values (7, '怒りっぽい');

insert into maker_start_list (id, start_value) values (8, '裸の');

insert into maker_start_list (id, start_value) values (9, '死にかけの');

insert into maker_start_list (id, start_value) values (10, '職人気質の');

insert into maker_start_list (id, start_value) values (11, '孤独な');

insert into maker_start_list (id, start_value) values (12, 'ディフェンスに定評のある');

insert into maker_start_list (id, start_value) values (13, '寂しがりの');

insert into maker_start_list (id, start_value) values (14, 'ネガティブな');

insert into maker_start_list (id, start_value) values (15, 'ポジティブな');

insert into maker_start_list (id, start_value) values (16, '徹夜明けの');

insert into maker_start_list (id, start_value) values (17, '最強の');

insert into maker_start_list (id, start_value) values (18, '最弱の');

insert into maker_start_list (id, start_value) values (19, '人気物の');

insert into maker_start_list (id, start_value) values (20, '嫌われ物の');

insert into maker_start_list (id, start_value) values (21, '筋肉がすごい');

insert into maker_start_list (id, start_value) values (22, '地元じゃ負け知らずの');

insert into maker_start_list (id, start_value) values (23, '眼鏡をかけた');

insert into maker_start_list (id, start_value) values (24, 'チート能力をもらった');

insert into maker_start_list (id, start_value) values (25, '還暦を迎えた');

insert into maker_start_list (id, start_value) values (26, 'おしとやかな');

insert into maker_start_list (id, start_value) values (27, 'めんどくさがりの');

insert into maker_start_list (id, start_value) values (28, 'やるときはやる');

insert into maker_start_list (id, start_value) values (29, '手先が器用な');

insert into maker_start_list (id, start_value) values (30, '都大会ベスト8の');

insert into maker_start_list (id, start_value) values (31, 'みんなの相談役の');

insert into maker_start_list (id, start_value) values (32, 'Sランクの');

insert into maker_start_list (id, start_value) values (33, 'Aランクの');

insert into maker_start_list (id, start_value) values (34, 'Bランクの');

insert into maker_start_list (id, start_value) values (35, 'Cランクの');

insert into maker_start_list (id, start_value) values (36, 'Dランクの');

insert into maker_start_list (id, start_value) values (37, 'Eランクの');

insert into maker_start_list (id, start_value) values (38, 'リーゼントの');

insert into maker_start_list (id, start_value) values (39, 'オッドアイの');

insert into maker_start_list (id, start_value) values (40, '3丁目の');

insert into maker_start_list (id, start_value) values (41, '最後までチョコたっぷりの');

insert into maker_start_list (id, start_value) values (42, '脇汗がすごい');

insert into maker_start_list (id, start_value) values (43, 'ダイエット中の');

insert into maker_start_list (id, start_value) values (44, 'モテモテな');

insert into maker_start_list (id, start_value) values (45, 'ダンディな');

insert into maker_start_list (id, start_value) values (46, '貧乏な');

insert into maker_start_list (id, start_value) values (47, '脱サラした');

insert into maker_start_list (id, start_value) values (48, '毛根が薄い');

insert into maker_start_list (id, start_value) values (49, '顎がしゃくれた');

insert into maker_start_list (id, start_value) values (50, '中二病の');