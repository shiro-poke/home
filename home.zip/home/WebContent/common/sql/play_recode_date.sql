create table play_recode_date (
	play_date date not null
);

select * from play_recode_date;

insert into play_recode_date (play_date) value ('1990-01-01');