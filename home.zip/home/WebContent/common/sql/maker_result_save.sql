create table maker_result_save (
	name varchar(100) primary key,
	maker_result varchar(100) not null
);

select * from maker_result_save;

insert into maker_result_save (name, maker_result) values ('', '');

delete from maker_result_save;