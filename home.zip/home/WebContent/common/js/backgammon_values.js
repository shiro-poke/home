//バックギャモン：変数のまとめ

const ITEM_NUM = 15; //各色の駒の個数
const ITEM_SIZE = 39; //駒の縦サイズ

const SQU_NUM = 24; //マスの個数

const LEFT_ITEM_1 = 38; //左エリア、左から1つ目の駒配置
const LEFT_ITEM_2 = 85; //左エリア、左から2つ目の駒配置
const LEFT_ITEM_3 = 133; //左エリア、左から3つ目の駒配置
const LEFT_ITEM_4 = 181; //左エリア、左から4つ目の駒配置
const LEFT_ITEM_5 = 232; //左エリア、左から5つ目の駒配置
const LEFT_ITEM_6 = 279; //左エリア、左から6つ目の駒配置

const RIGHT_ITEM_1 = 379; //右エリア、左から1つ目の駒配置
const RIGHT_ITEM_2 = 427; //右エリア、左から2つ目の駒配置
const RIGHT_ITEM_3 = 475; //右エリア、左から3つ目の駒配置
const RIGHT_ITEM_4 = 524; //右エリア、左から4つ目の駒配置
const RIGHT_ITEM_5 = 574; //右エリア、左から5つ目の駒配置
const RIGHT_ITEM_6 = 619; //右エリア、左から6つ目の駒配置

const TOP_BASE_ITEM = 25; //上段の最上位置の駒配置
const BOTTOM_BASE_ITEM = 410; //下段の最下位置の駒配置
const SET_ITEM_MAX = 5; //重ねずに駒をおける最大個数

const LEFT_SQU_1 = 42; //左エリア、左から1つ目のマス配置
const LEFT_SQU_2 = 89; //左エリア、左から2つ目のマス配置
const LEFT_SQU_3 = 137; //左エリア、左から3つ目のマス配置
const LEFT_SQU_4 = 186; //左エリア、左から4つ目のマス配置
const LEFT_SQU_5 = 236; //左エリア、左から5つ目のマス配置
const LEFT_SQU_6 = 281; //左エリア、左から6つ目のマス配置

const RIGHT_SQU_1 = 384; //右エリア、左から1つ目のマス配置
const RIGHT_SQU_2 = 431; //右エリア、左から2つ目のマス配置
const RIGHT_SQU_3 = 479; //右エリア、左から3つ目のマス配置
const RIGHT_SQU_4 = 528; //右エリア、左から4つ目のマス配置
const RIGHT_SQU_5 = 578; //右エリア、左から5つ目のマス配置
const RIGHT_SQU_6 = 623; //右エリア、左から6つ目のマス配置

const TOP_BASE_SQU = 10; //上段のマス配置
const BOTTOM_BASE_SQU = 252; //下段のマス配置

const GOLE_LEFT_SQU = 693; //プレイヤーのゴールマスの横位置
const GOLE_TOP_SQU = 20; //プレイヤーのゴールマスの縦位置

const STANDBY_LEFT = 328; //取られた駒の横位置

const GOLE_LEFT = 715; //ゴール駒の横配置
const GOLE_TOP_PLAYER = 29; //プレイヤーのゴール駒の縦配置
const GOLE_TOP_ENEMY = 311; //相手のゴール駒の縦配置
const GOLE_SPACE = 7; //ゴールに置く駒の間隔

const DICE_NUM = 4; //サイコロの最大個数
const DICE_SIZE = 39; //サイコロのサイズ

const DICE_TOP_CENTER = 130; //サイコロの縦位置(中央表示)
const DICE_LEFT_CENTER = 370; //サイコロの横位置(中央表示)

const DICE_TOP_STANDBY = 218; //サイコロの縦位置(待機表示)
const DICE_LEFT_STANDBY = 716; //サイコロの横位置(待機表示)

const DICE_LIST = [0, 0, 0, 0]; //進められるマス数のリスト(ゾロ目の場合倍になるため2×2の4要素)
const ITEM_POSITION = ['', '', '', '', '', '', '', '', '', '', '', '',
					   '', '', '', '', '', '', '', '', '', '', '', '']; //ボード上の駒配置(6×4の24箇所)

const IMG_FILES = '../common/img/backgammon/'; //画像ファイルの場所

const TEXT_TOP = DICE_TOP_CENTER + 80; //テキストの縦位置
const TEXT_LEFT = DICE_LEFT_CENTER - (DICE_SIZE + 95); //テキストの横位置

const ENEMY_ITEM_MOVE = [24, 24]; //相手の駒の動き(移動元、移動先を登録)

let play_game = false; //ゲーム開始判定用
let turn_order = false; //どちらが先攻かの判定用(プレイヤー先攻でtrue)
let player_turn = true; //どちらのターンかの判定用
let enemy_move = 1; //相手のターンの段階

let player_color = ''; //プレイヤーの駒の色
let enemy_color = ''; //敵の駒の色

let dice_num_1 = 0; //1つ目のサイコロの目
let dice_num_2 = 0; //2つ目のサイコロの目

let player_gole = 0; //プレイヤーのゴール駒数
let enemy_gole = 0; //プレイヤーのゴール駒数

let player_standby = 0; //プレイヤーの取られた駒数
let enemy_standby = 0; //相手の取られた駒数

let select_item_pos = -1; //選択している駒のポジション
let move_pos_array = []; //移動できる箇所の格納用変数

let load_count = 0; //画像読み込みカウント変数