//バックギャモン：画像表示の設定

//ゲーム開始時の配置(先攻決めた後の処理)
function startPosition() {
	//ゲーム開始判定の有効化
	play_game = true;
	player_turn = turn_order;

	//画面のリセット
	resetGame();

	//どちらが先攻かで分岐(駒の初期配置を設定)
	if(turn_order) {
		ITEM_POSITION[0] = '白2';
		ITEM_POSITION[5] = '黒5';
		ITEM_POSITION[7] = '黒3';
		ITEM_POSITION[11] = '白5';
		ITEM_POSITION[12] = '黒5';
		ITEM_POSITION[16] = '白3';
		ITEM_POSITION[18] = '白5';
		ITEM_POSITION[23] = '黒2';
	} else {
		ITEM_POSITION[0] = '黒2';
		ITEM_POSITION[5] = '白5';
		ITEM_POSITION[7] = '白3';
		ITEM_POSITION[11] = '黒5';
		ITEM_POSITION[12] = '白5';
		ITEM_POSITION[16] = '黒3';
		ITEM_POSITION[18] = '黒5';
		ITEM_POSITION[23] = '白2';
	}

	//駒の配置
	setItemPosition();

	//サイコロの配置
	setDicePosition('standby');
}

//ボード上の駒の配置(ITEM_POSITIONを利用して配置を行う)
function setItemPosition() {
	let element = null; //取得したID格納用変数
	let count = 0; //ループ変数
	let white_img_num = 1; //白駒の画像番号
	let black_img_num = 1; //黒駒の画像番号
	let img_num = 0; //使用する画像番号

	//駒を設置できる範囲の個数分ループ
	while(count < ITEM_POSITION.length) {
		let item_id_head = ''; //取得するIDの頭部分

		//駒の色の判別
		if(ITEM_POSITION[count].startsWith('白')) {
			item_id_head = 'white';
			img_num = white_img_num;
		} else if(ITEM_POSITION[count].startsWith('黒')) {
			item_id_head = 'black';
			img_num = black_img_num;
		}

		//駒の色を判別できた場合のみ処理を行う
		if(item_id_head != '') {
			const SET_POSITION = count;
			let left_position = 0;

			//基盤のどの箇所に配置するかで分岐
			switch(SET_POSITION) {
				case 0:
				case 23:
					left_position = RIGHT_ITEM_6;
					break;
				case 1:
				case 22:
					left_position = RIGHT_ITEM_5;
					break;
				case 2:
				case 21:
					left_position = RIGHT_ITEM_4;
					break;
				case 3:
				case 20:
					left_position = RIGHT_ITEM_3;
					break;
				case 4:
				case 19:
					left_position = RIGHT_ITEM_2;
					break;
				case 5:
				case 18:
					left_position = RIGHT_ITEM_1;
					break;
				case 6:
				case 17:
					left_position = LEFT_ITEM_6;
					break;
				case 7:
				case 16:
					left_position = LEFT_ITEM_5;
					break;
				case 8:
				case 15:
					left_position = LEFT_ITEM_4;
					break;
				case 9:
				case 14:
					left_position = LEFT_ITEM_3;
					break;
				case 10:
				case 13:
					left_position = LEFT_ITEM_2;
					break;
				case 11:
				case 12:
					left_position = LEFT_ITEM_1;
					break;
				default:
					alert('予期せぬ番号「' + SET_POSITION + '」が入力されました');
					return;
			}

			const SET_IMG_NUM = Number(ITEM_POSITION[count].slice(1, ITEM_POSITION[count].length));
			let sub_count = 0;
			let average_num = SET_IMG_NUM - 1;

			//設置する駒の数が重ねずにすべて表示できる範囲内かの判定
			if(SET_IMG_NUM <= SET_ITEM_MAX) {
				average_num = SET_ITEM_MAX - 1;
			}

			//その範囲に設置する駒の分ループ
			while(sub_count < SET_IMG_NUM) {
				//駒の表示
				element = document.getElementById(item_id_head + '_item_' + img_num);
				element.style.display = 'block';
				element.style.left = left_position + 'px';

				//駒の範囲が上下どちらかの判別
				if(SET_POSITION < 12) {
					element.style.top =
						(BOTTOM_BASE_ITEM - (ITEM_SIZE * (SET_ITEM_MAX - 1) * (sub_count / average_num))) + 'px';
				} else {
					element.style.top =
						(TOP_BASE_ITEM + (ITEM_SIZE * (SET_ITEM_MAX - 1) * (sub_count / average_num))) + 'px';
				}

				img_num = img_num + 1;
				sub_count = sub_count + 1;
			}

		}

		//使用可能な画像番号を保持
		if(ITEM_POSITION[count].startsWith('白')) {
			white_img_num = img_num;
		} else if(ITEM_POSITION[count].startsWith('黒')) {
			black_img_num = img_num;
		}

		count = count + 1;
	}

	//プレイヤーの取られている駒があるかの判定
	if(player_standby > 0) {
		let sub_count_1 = 0;
		let id_name_head = '';

		//どちらの先攻かによって処理する駒の色を判定
		if(turn_order) {
			id_name_head = 'white';
			img_num = white_img_num;
		} else {
			id_name_head = 'black';
			img_num = black_img_num;
		}

		//プレイヤーの取られている駒分ループして表示設定を行う
		while(sub_count_1 < player_standby) {
			element = document.getElementById(id_name_head + '_item_' + img_num);
			element.style.display = 'block';
			element.style.top = (BOTTOM_BASE_ITEM - (ITEM_SIZE * sub_count_1)) + 'px';
			element.style.left = STANDBY_LEFT + 'px';

			img_num = img_num + 1;
			sub_count_1 = sub_count_1 + 1;
		}

		//使用可能な画像番号を保持
		if(turn_order) {
			white_img_num = img_num;
		} else {
			black_img_num = img_num;
		}

	}

	//相手の取られている駒があるかの判定
	if(enemy_standby > 0) {
		let sub_count_2 = 0;
		let id_name_head = '';

		//どちらの先攻かによって処理する駒の色を判定
		if(turn_order) {
			id_name_head = 'black';
			img_num = black_img_num;
		} else {
			id_name_head = 'white';
			img_num = white_img_num;
		}

		//相手の取られている駒分ループして表示設定を行う
		while(sub_count_2 < enemy_standby) {
			element = document.getElementById(id_name_head + '_item_' + img_num);
			element.style.display = 'block';
			element.style.top = (TOP_BASE_ITEM + (ITEM_SIZE * sub_count_2)) + 'px';
			element.style.left = STANDBY_LEFT + 'px';

			img_num = img_num + 1;
			sub_count_2 = sub_count_2 + 1;
		}

		//使用可能な画像番号を保持
		if(turn_order) {
			black_img_num = img_num;
		} else {
			white_img_num = img_num;
		}

	}

	let gole_count = 0; //駒の縦位置調整に使用

	//表示設定を行えていない白駒の分ループしゴールしている駒の表示設定を行う
	while(white_img_num <= ITEM_NUM) {
		element = document.getElementById('white_item_' + white_img_num);
		element.style.display = 'block';
		element.style.left = GOLE_LEFT + 'px';

		//どちらの先攻かによって値を設定
		if(turn_order) {
			element.style.top = (GOLE_TOP_PLAYER + (GOLE_SPACE * gole_count)) + 'px';
		} else {
			element.style.top = (GOLE_TOP_ENEMY + (GOLE_SPACE * gole_count)) + 'px';
		}

		white_img_num = white_img_num + 1;
		gole_count = gole_count + 1;
	}

	gole_count = 0;

	//表示設定を行えていない黒駒の分ループしゴールしている駒の表示設定を行う
	while(black_img_num <= ITEM_NUM) {
		element = document.getElementById('black_item_' + black_img_num);
		element.style.display = 'block';
		element.style.left = GOLE_LEFT + 'px';

		//どちらの先攻かによって値を設定
		if(turn_order) {
			element.style.top = (GOLE_TOP_ENEMY + (GOLE_SPACE * gole_count)) + 'px';
		} else {
			element.style.top = (GOLE_TOP_PLAYER + (GOLE_SPACE * gole_count)) + 'px';
		}

		black_img_num = black_img_num + 1;
		gole_count = gole_count + 1;
	}

	//プレーヤーのターンの場合に駒の選択可能時のカーソルを切り替え
	if(player_turn) {
		cursorOn();
	}

}

//駒のIDからポジション番号を取得
function getPositionNum(element) {
	let result_num = -1; //処理結果
	const LEFT_NUM = Number(element.style.left.slice(0, element.style.left.length - 2));
	const TOP_NUM = Number(element.style.top.slice(0, element.style.top.length - 2));

	//縦と横の位置よりポジション番号を取得
	switch(LEFT_NUM) {
		case RIGHT_ITEM_6:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 23;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 0;
			}

			break;
		case RIGHT_ITEM_5:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 22;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 1;
			}

			break;
		case RIGHT_ITEM_4:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 21;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 2;
			}

			break;
		case RIGHT_ITEM_3:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 20;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 3;
			}

			break;
		case RIGHT_ITEM_2:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 19;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 4;
			}

			break;
		case RIGHT_ITEM_1:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 18;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 5;
			}

			break;
		case LEFT_ITEM_6:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 17;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 6;
			}

			break;
		case LEFT_ITEM_5:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 16;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 7;
			}

			break;
		case LEFT_ITEM_4:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 15;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 8;
			}

			break;
		case LEFT_ITEM_3:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 14;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 9;
			}

			break;
		case LEFT_ITEM_2:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 13;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 10;
			}

			break;
		case LEFT_ITEM_1:

			if(TOP_NUM <= TOP_BASE_ITEM + (ITEM_SIZE * 4)) {
				result_num = 12;
			} else if(TOP_NUM >= BOTTOM_BASE_ITEM - (ITEM_SIZE * 4)) {
				result_num = 11;
			}

			break;
	}

	return result_num;
}

//進行できるマスを選択可能状態に設定
function setSquare() {
	//設定のリセット
	resetSquare();

	let count = 0;

	//登録した進行できるマスの数分ループ
	while(count < move_pos_array.length) {
		const CHECK_POS = move_pos_array[count];
		let element = null;
		let left_position = 0;
		let top_position = 0;

		//横位置の判定
		switch(CHECK_POS) {
			case 0:
			case 23:
				left_position = RIGHT_SQU_6;
				break;
			case 1:
			case 22:
				left_position = RIGHT_SQU_5;
				break;
			case 2:
			case 21:
				left_position = RIGHT_SQU_4;
				break;
			case 3:
			case 20:
				left_position = RIGHT_SQU_3;
				break;
			case 4:
			case 19:
				left_position = RIGHT_SQU_2;
				break;
			case 5:
			case 18:
				left_position = RIGHT_SQU_1;
				break;
			case 6:
			case 17:
				left_position = LEFT_SQU_6;
				break;
			case 7:
			case 16:
				left_position = LEFT_SQU_5;
				break;
			case 8:
			case 15:
				left_position = LEFT_SQU_4;
				break;
			case 9:
			case 14:
				left_position = LEFT_SQU_3;
				break;
			case 10:
			case 13:
				left_position = LEFT_SQU_2;
				break;
			case 11:
			case 12:
				left_position = LEFT_SQU_1;
				break;
			case 24:
				left_position = GOLE_LEFT_SQU;
				break;
			default:
		}

		//ゴールまで進行できるかの判定
		if(CHECK_POS == 24) {
			element = document.getElementById('gole_poket');
			top_position = GOLE_TOP_SQU;
		} else {
			element = document.getElementById('square_' + (CHECK_POS + 1));

			//縦位置の判定
			if(CHECK_POS < 12) {
				top_position = BOTTOM_BASE_SQU;
			} else {
				top_position = TOP_BASE_SQU;
			}

		}

		element.style.display = 'block';
		element.style.top = top_position + 'px';
		element.style.left = left_position + 'px';
		element.style.cursor = 'pointer';

		count = count + 1;
	}

}
