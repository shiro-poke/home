//相手ターンの処理

//相手ターンの流れ
function enemyMove() {

	//相手のターンであるかの判定
	if(play_game && !player_turn) {
		const CHECK_MOVE = enemy_move;
		sleep(1500);

		//ターンの始め、終わり以外であるかの判定
		if(CHECK_MOVE > 1 && CHECK_MOVE < 6) {

			//駒が動かせない場合に処理
			if(!allMoveCheck()) {
				//表示設定
				setDicePosition('standby');

				//テキスト設定
				let element = document.getElementById('text_message');
				element.style.display = 'block';
				element.style.top = TEXT_TOP + 'px';
				element.style.left = TEXT_LEFT + 'px';

				element = document.getElementById('message_img');
				element.src = IMG_FILES + 'テキスト_ターンスキップ.png';

				enemy_move = 6;
				return;
			}

		}

		//ターンの進行度によって分岐
		switch(CHECK_MOVE) {
			case 1:
				playDice();
				enemy_move = enemy_move + 1;
				break;
			case 2:
				enemyBrain();
				enemy_move = enemy_move + 1;
				break;
			case 3:
				enemyBrain();

				if(DICE_LIST[0] != 0) {
					enemy_move = enemy_move + 1;
				} else {
					setItemPosition();
					enemy_move = 6;
				}

				break;
			case 4:
				enemyBrain();

				if(DICE_LIST[0] != 0) {
					enemy_move = enemy_move + 1;
				} else {
					setItemPosition();
					enemy_move = 6;
				}

				break;
			case 5:
				enemyBrain();
				enemy_move = enemy_move + 1;
				break;
			case 6:
				setItemPosition();
				enemy_move = 1;
				player_turn = true;
				startDice();
				break;
			default:
		}

	}

}

//相手の駒の進行パターンの登録
function enemyBrain() {
	let count = 0;
	let gole_possible = true;

	//相手の進行情報を初期化
	ENEMY_ITEM_MOVE[0] = 99;
	ENEMY_ITEM_MOVE[1] = 99;

	//相手の取られている駒がないかの判定
	if(enemy_standby == 0) {
		count = ITEM_POSITION.length / 4;

		//ゴール不可能範囲でループ
		while(count < ITEM_POSITION.length) {

			//ゴール不可能範囲に相手の駒があるかの判定
			if(ITEM_POSITION[count].startsWith(enemy_color)) {
				gole_possible = false;
			}

			count = count + 1;
		}

		if(enemy_standby > 0) {
			gole_possible = false;
		}

		//ゴール可能であるかの判定
		if(gole_possible) {

			//プレイヤーの取られた駒の有無で処理順を変更
			if(player_standby > 0) {
				count = 0;

				//ゴール可能範囲内でループ(駒を複数重ねられるかの進行判定)
				while(count < ITEM_POSITION.length / 4) {

					//相手の駒1つだけのマスであるかの判定
					if(ITEM_POSITION[count] == enemy_color + '1') {

						//サイコロの数の大小により比較順を変更
						if(DICE_LIST[0] >= DICE_LIST[1]) {

							//大きい方のサイコロの数の判定
							if(DICE_LIST[0] > 0) {

								//サイコロの数進行して指定マスに駒をおけるかの判定
								if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							}

							//小さい方のサイコロの数の判定
							if(DICE_LIST[1] > 0) {

								//サイコロの数進行して指定マスに駒をおけるかの判定
								if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							}

						} else {

							//大きい方のサイコロの数の判定
							if(DICE_LIST[1] > 0) {

								//サイコロの数進行して指定マスに駒をおけるかの判定
								if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							}

							//小さい方のサイコロの数の判定
							if(DICE_LIST[0] > 0) {

								//サイコロの数進行して指定マスに駒をおけるかの判定
								if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							}

						}

					}

					count = count + 1;
				}

				//情報が登録されていない場合、処理を続ける
				if(ENEMY_ITEM_MOVE[0] == 99 || ENEMY_ITEM_MOVE[1] == 99) {
					count = ITEM_POSITION.length / 4;

					//ゴール可能範囲内でループ(遠い位置から順にゴールに移動できるかの進行判定)
					while(count >= 0) {

						//相手の駒があるマスの判定
						if(ITEM_POSITION[count].startsWith(enemy_color)) {

							//サイコロの数の大小により比較順を変更
							if(DICE_LIST[0] >= DICE_LIST[1]) {

								//大きい方の数で進行できるかの判定
								if(DICE_LIST[0] > 0) {

									//ゴールまで進行できるかの判定
									if(count - DICE_LIST[0] < 0) {
										ENEMY_ITEM_MOVE[0] = count;
										ENEMY_ITEM_MOVE[1] = -1;
										break;
									}

								}

								//小さい方の数で進行できるかの判定
								if(DICE_LIST[1] > 0) {

									//ゴールまで進行できるかの判定
									if(count - DICE_LIST[1] < 0) {
										ENEMY_ITEM_MOVE[0] = count;
										ENEMY_ITEM_MOVE[1] = -1;
										break;
									}

								}

							} else {

								//大きい方の数で進行できるかの判定
								if(DICE_LIST[1] > 0) {

									//ゴールまで進行できるかの判定
									if(count - DICE_LIST[1] < 0) {
										ENEMY_ITEM_MOVE[0] = count;
										ENEMY_ITEM_MOVE[1] = -1;
										break;
									}

								}

								//小さい方の数で進行できるかの判定
								if(DICE_LIST[0] > 0) {

									//ゴールまで進行できるかの判定
									if(count - DICE_LIST[0] < 0) {
										ENEMY_ITEM_MOVE[0] = count;
										ENEMY_ITEM_MOVE[1] = -1;
										break;
									}

								}

							}

						}

						count = count - 1;
					}

				}

			} else {
				count = ITEM_POSITION.length / 4;

				//ゴール可能範囲内でループ(遠い位置から順にゴールに移動できるかの進行判定)
				while(count >= 0) {

					//相手の駒があるマスの判定
					if(ITEM_POSITION[count].startsWith(enemy_color)) {

						//サイコロの数の大小により比較順を変更
						if(DICE_LIST[0] >= DICE_LIST[1]) {

							//大きい方の数で進行できるかの判定
							if(DICE_LIST[0] > 0) {

								//ゴールまで進行できるかの判定
								if(count - DICE_LIST[0] < 0) {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = -1;
									break;
								}

							}

							//小さい方の数で進行できるかの判定
							if(DICE_LIST[1] > 0) {

								//ゴールまで進行できるかの判定
								if(count - DICE_LIST[1] < 0) {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = -1;
									break;
								}

							}

						} else {

							//大きい方の数で進行できるかの判定
							if(DICE_LIST[1] > 0) {

								//ゴールまで進行できるかの判定
								if(count - DICE_LIST[1] < 0) {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = -1;
									break;
								}

							}

							//小さい方の数で進行できるかの判定
							if(DICE_LIST[0] > 0) {

								//ゴールまで進行できるかの判定
								if(count - DICE_LIST[0] < 0) {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = -1;
									break;
								}

							}

						}

					}

					count = count - 1;
				}

				//情報が登録されていない場合、処理を続ける
				if(ENEMY_ITEM_MOVE[0] == 99 || ENEMY_ITEM_MOVE[1] == 99) {
					count = 0;

					//ゴール可能範囲内でループ(駒を複数重ねられるかの進行判定)
					while(count < ITEM_POSITION.length / 4) {

						//相手の駒1つだけのマスであるかの判定
						if(ITEM_POSITION[count] == enemy_color + '1') {

							//サイコロの数の大小により比較順を変更
							if(DICE_LIST[0] >= DICE_LIST[1]) {

								//大きい方のサイコロの数の判定
								if(DICE_LIST[0] > 0) {

									//サイコロの数進行して指定マスに駒をおけるかの判定
									if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
										ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
										ENEMY_ITEM_MOVE[1] = count;
										break;
									}

								}

								//小さい方のサイコロの数の判定
								if(DICE_LIST[1] > 0) {

									//サイコロの数進行して指定マスに駒をおけるかの判定
									if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
										ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
										ENEMY_ITEM_MOVE[1] = count;
										break;
									}

								}

							} else {

								//大きい方のサイコロの数の判定
								if(DICE_LIST[1] > 0) {

									//サイコロの数進行して指定マスに駒をおけるかの判定
									if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
										ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
										ENEMY_ITEM_MOVE[1] = count;
										break;
									}

								}

								//小さい方のサイコロの数の判定
								if(DICE_LIST[0] > 0) {

									//サイコロの数進行して指定マスに駒をおけるかの判定
									if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
										ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
										ENEMY_ITEM_MOVE[1] = count;
										break;
									}

								}

							}

						}

						count = count + 1;
					}

				}

			}

			//情報が登録されていない場合、処理を続ける
			if(ENEMY_ITEM_MOVE[0] == 99 || ENEMY_ITEM_MOVE[1] == 99) {
				count = ITEM_POSITION.length / 4 - 1;

				//ゴール可能範囲内でループ(プレイヤーの駒が取れるかの進行判定)
				while(count >= 0) {

					//プレイヤーの駒が1つだけあるかの判定
					if(ITEM_POSITION[count] == player_color + '1') {

						//サイコロの数の大小により比較順を変更
						if(DICE_LIST[0] >= DICE_LIST[1]) {

							//確認したマスからサイコロの数戻った箇所にマスがあるかの判定
							if(DICE_LIST[0] > 0 && count + DICE_LIST[0] < ITEM_POSITION.length) {

								//確認した駒をとれる位置に駒があるかの判定
								if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							} else if(DICE_LIST[1] > 0 && count + DICE_LIST[1] < ITEM_POSITION.length) {

								//確認した駒をとれる位置に駒があるかの判定
								if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							}

						} else {

							//確認したマスからサイコロの数戻った箇所にマスがあるかの判定
							if(DICE_LIST[1] > 0 && count + DICE_LIST[1] < ITEM_POSITION.length) {

								//確認した駒をとれる位置に駒があるかの判定
								if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							} else if(DICE_LIST[0] > 0 && count + DICE_LIST[0] < ITEM_POSITION.length) {

								//確認した駒をとれる位置に駒があるかの判定
								if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							}

						}

					}

					count = count - 1;
				}

			}

			//情報が登録されていない場合、処理を続ける
			if(ENEMY_ITEM_MOVE[0] == 99 || ENEMY_ITEM_MOVE[1] == 99) {
				count = ITEM_POSITION.length / 4 - 1;

				//ゴール可能範囲内でループ(遠い位置から順に移動できるかの進行判定)
				while(count >= 0) {

					//相手の駒があるマスの判定
					if(ITEM_POSITION[count].startsWith(enemy_color)) {

						//サイコロの数の大小により比較順を変更
						if(DICE_LIST[0] >= DICE_LIST[1]) {

							//大きい方の数で進行できるかの判定
							if(DICE_LIST[0] > 0) {

								if(!ITEM_POSITION[count - DICE_LIST[0]].startsWith(player_color) ||
									ITEM_POSITION[count - DICE_LIST[0]] == player_color + '1') {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = count - DICE_LIST[0];
									break;
								}

							}

							//小さい方の数で進行できるかの判定
							if(DICE_LIST[1] > 0) {

								if(!ITEM_POSITION[count - DICE_LIST[1]].startsWith(player_color) ||
									ITEM_POSITION[count - DICE_LIST[1]] == player_color + '1') {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = count - DICE_LIST[1];
									break;
								}

							}

						} else {

							//大きい方の数で進行できるかの判定
							if(DICE_LIST[1] > 0) {

								if(!ITEM_POSITION[count - DICE_LIST[1]].startsWith(player_color) ||
									ITEM_POSITION[count - DICE_LIST[1]] == player_color + '1') {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = count - DICE_LIST[1];
									break;
								}

							}

							//小さい方の数で進行できるかの判定
							if(DICE_LIST[0] > 0) {

								if(!ITEM_POSITION[count - DICE_LIST[0]].startsWith(player_color) ||
									ITEM_POSITION[count - DICE_LIST[0]] == player_color + '1') {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = count - DICE_LIST[0];
									break;
								}

							}

						}

					}

					count = count - 1;
				}

			}

		} else {
			count = 0;

			//マスの数ループ(駒を複数重ねられるかの進行判定)
			while(count < ITEM_POSITION.length) {

				//相手の駒1つだけのマスであるかの判定
				if(ITEM_POSITION[count] == enemy_color + '1') {

					//サイコロの数の大小により比較順を変更
					if(DICE_LIST[0] >= DICE_LIST[1]) {

						//大きい方のサイコロの数の判定
						if(DICE_LIST[0] > 0 && count + DICE_LIST[0] < ITEM_POSITION.length) {

							//サイコロの数進行して指定マスに駒をおけるかの判定
							if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
								ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
								ENEMY_ITEM_MOVE[1] = count;
								break;
							}

						}

						//小さい方のサイコロの数の判定
						if(DICE_LIST[1] > 0 && count + DICE_LIST[1] < ITEM_POSITION.length) {

							//サイコロの数進行して指定マスに駒をおけるかの判定
							if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
								ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
								ENEMY_ITEM_MOVE[1] = count;
								break;
							}

						}

					} else {

						//大きい方のサイコロの数の判定
						if(DICE_LIST[1] > 0 && count + DICE_LIST[1] < ITEM_POSITION.length) {

							//サイコロの数進行して指定マスに駒をおけるかの判定
							if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
								ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
								ENEMY_ITEM_MOVE[1] = count;
								break;
							}

						}

						//小さい方のサイコロの数の判定
						if(DICE_LIST[0] > 0 && count + DICE_LIST[0] < ITEM_POSITION.length) {

							//サイコロの数進行して指定マスに駒をおけるかの判定
							if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
								ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
								ENEMY_ITEM_MOVE[1] = count;
								break;
							}

						}

					}

				}

				count = count + 1;
			}

			//情報が登録されていない場合、処理を続ける
			if(ENEMY_ITEM_MOVE[0] == 99 || ENEMY_ITEM_MOVE[1] == 99) {
				count = ITEM_POSITION.length - 1;

				//マスの数ループ(プレイヤーの駒が取れるかの進行判定)
				while(count >= 0) {

					//プレイヤーの駒が1つだけあるかの判定
					if(ITEM_POSITION[count] == player_color + '1') {

						//サイコロの数の大小により比較順を変更
						if(DICE_LIST[0] >= DICE_LIST[1]) {

							//確認したマスからサイコロの数戻った箇所にマスがあるかの判定
							if(DICE_LIST[0] > 0 && count + DICE_LIST[0] < ITEM_POSITION.length) {

								//確認した駒をとれる位置に駒があるかの判定
								if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							} else if(DICE_LIST[1] > 0 && count + DICE_LIST[1] < ITEM_POSITION.length) {

								//確認した駒をとれる位置に駒があるかの判定
								if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							}

						} else {

							//確認したマスからサイコロの数戻った箇所にマスがあるかの判定
							if(DICE_LIST[1] > 0 && count + DICE_LIST[1] < ITEM_POSITION.length) {

								//確認した駒をとれる位置に駒があるかの判定
								if(ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[1];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							} else if(DICE_LIST[0] > 0 && count + DICE_LIST[0] < ITEM_POSITION.length) {

								//確認した駒をとれる位置に駒があるかの判定
								if(ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
									ENEMY_ITEM_MOVE[0] = count + DICE_LIST[0];
									ENEMY_ITEM_MOVE[1] = count;
									break;
								}

							}

						}

					}

					count = count - 1;
				}

			}

			//情報が登録されていない場合、処理を続ける
			if(ENEMY_ITEM_MOVE[0] == 99 || ENEMY_ITEM_MOVE[1] == 99) {
				count = ITEM_POSITION.length - 1;

				//マスの数ループ(遠い位置から順に移動できるかの進行判定)
				while(count >= 0) {

					//相手の駒があるマスの判定
					if(ITEM_POSITION[count].startsWith(enemy_color)) {

						//サイコロの数の大小により比較順を変更
						if(DICE_LIST[0] >= DICE_LIST[1]) {

							//大きい方の数で進行できるかの判定
							if(DICE_LIST[0] > 0 && count - DICE_LIST[0] >= 0) {

								if(!ITEM_POSITION[count - DICE_LIST[0]].startsWith(player_color) ||
									ITEM_POSITION[count - DICE_LIST[0]] == player_color + '1') {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = count - DICE_LIST[0];
									break;
								}

							}

							//小さい方の数で進行できるかの判定
							if(DICE_LIST[1] > 0 && count - DICE_LIST[1] >= 0) {

								if(!ITEM_POSITION[count - DICE_LIST[1]].startsWith(player_color) ||
									ITEM_POSITION[count - DICE_LIST[1]] == player_color + '1') {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = count - DICE_LIST[1];
									break;
								}

							}

						} else {

							//大きい方の数で進行できるかの判定
							if(DICE_LIST[1] > 0 && count - DICE_LIST[1] >= 0) {

								if(!ITEM_POSITION[count - DICE_LIST[1]].startsWith(player_color) ||
									ITEM_POSITION[count - DICE_LIST[1]] == player_color + '1') {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = count - DICE_LIST[1];
									break;
								}

							}

							//小さい方の数で進行できるかの判定
							if(DICE_LIST[0] > 0 && count - DICE_LIST[0] >= 0) {

								if(!ITEM_POSITION[count - DICE_LIST[0]].startsWith(player_color) ||
									ITEM_POSITION[count - DICE_LIST[0]] == player_color + '1') {
									ENEMY_ITEM_MOVE[0] = count;
									ENEMY_ITEM_MOVE[1] = count - DICE_LIST[0];
									break;
								}

							}

						}

					}

					count = count - 1;
				}

			}

		}

	} else {

		//サイコロの数の大小により比較順を変更
		if(DICE_LIST[0] <= DICE_LIST[1]) {

			//進行先に取れるプレイヤーの駒があるか判定
			if(DICE_LIST[0] > 0 && ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[0]] == player_color + '1') {
				ENEMY_ITEM_MOVE[0] = ITEM_POSITION.length;
				ENEMY_ITEM_MOVE[1] = ITEM_POSITION.length - DICE_LIST[0];
			} else if(DICE_LIST[1] > 0 && ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[1]] == player_color + '1') {
				ENEMY_ITEM_MOVE[0] = ITEM_POSITION.length;
				ENEMY_ITEM_MOVE[1] = ITEM_POSITION.length - DICE_LIST[1];
			} else {

				//大きい方の数で進行できるかの判定
				if(DICE_LIST[0] > 0) {

					if(!ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[0]].startsWith(player_color)) {
						ENEMY_ITEM_MOVE[0] = ITEM_POSITION.length;
						ENEMY_ITEM_MOVE[1] = ITEM_POSITION.length - DICE_LIST[0];
					}

				}

				//小さい方の数で進行できるかの判定
				if((ENEMY_ITEM_MOVE[0] == 99 || ENEMY_ITEM_MOVE[1] == 99) && DICE_LIST[1] > 0) {

					if(!ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[1]].startsWith(player_color)) {
						ENEMY_ITEM_MOVE[0] = ITEM_POSITION.length;
						ENEMY_ITEM_MOVE[1] = ITEM_POSITION.length - DICE_LIST[1];
					}

				}

			}

		} else {

			//進行先に取れるプレイヤーの駒があるか判定
			if(DICE_LIST[1] > 0 && ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[1]] == player_color + '1') {
				ENEMY_ITEM_MOVE[0] = ITEM_POSITION.length;
				ENEMY_ITEM_MOVE[1] = ITEM_POSITION.length - DICE_LIST[1];
			} else if(DICE_LIST[0] > 0 && ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[0]] == player_color + '1') {
				ENEMY_ITEM_MOVE[0] = ITEM_POSITION.length;
				ENEMY_ITEM_MOVE[1] = ITEM_POSITION.length - DICE_LIST[0];
			} else {

				//大きい方の数で進行できるかの判定
				if(DICE_LIST[1] > 0) {

					if(!ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[1]].startsWith(player_color)) {
						ENEMY_ITEM_MOVE[0] = ITEM_POSITION.length;
						ENEMY_ITEM_MOVE[1] = ITEM_POSITION.length - DICE_LIST[1];
					}

				}

				//小さい方の数で進行できるかの判定
				if((ENEMY_ITEM_MOVE[0] == 99 || ENEMY_ITEM_MOVE[1] == 99) && DICE_LIST[0] > 0) {

					if(!ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[0]].startsWith(player_color)) {
						ENEMY_ITEM_MOVE[0] = ITEM_POSITION.length;
						ENEMY_ITEM_MOVE[1] = ITEM_POSITION.length - DICE_LIST[0];
					}

				}

			}

		}

	}

	//進行情報を取得できなかった場合、エラーを出す
	if(ENEMY_ITEM_MOVE[0] == 99 || ENEMY_ITEM_MOVE[1] == 99) {
		alert('進行パターンの取得に失敗しました');
		return;
	}

	select_item_pos = ENEMY_ITEM_MOVE[0];
	moveAfter(ENEMY_ITEM_MOVE[1]);
}