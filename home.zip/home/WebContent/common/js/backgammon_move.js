//バックギャモン：駒の動き

//駒のクリック時処理の設定
function cursorOn() {
	let element = null;
	let player_item = ''; //プレイヤーの駒色
	let enemy_item = ''; //相手の駒色

	if(player_color == '白') {
		player_item = 'white';
		enemy_item = 'black';
	} else {
		player_item = 'black';
		enemy_item = 'white';
	}

	let count = 1;

	//各駒の数分ループ
	while(count <= ITEM_NUM) {
		element = document.getElementById(player_item + '_item_' + count);
		const CHECK_MOVE = Number(element.style.left.slice(0, element.style.left.length - 2));

		//駒が操作可能範囲内にあるかの判定
		if(CHECK_MOVE <= RIGHT_ITEM_6) {
			element.style.cursor = 'pointer';

			//取られている駒であるかの判定
			if(CHECK_MOVE == STANDBY_LEFT) {
				element.onclick = new Function("playBackgammon('select_item_" + -1 + "')");
			} else {
				element.onclick = new Function("playBackgammon('select_item_" + getPositionNum(element) + "')");
			}

		} else {
			element.style.cursor = 'default';
			element.onclick = new Function("playBackgammon('reset_select')");
		}

		element = document.getElementById(enemy_item + '_item_' + count);
		element.style.cursor = 'default';
		element.onclick = new Function("playBackgammon('reset_select')");

		count = count + 1;
	}

}

//駒のクリック時処理設定のリセット
function cursorOff() {
	let element = null;
	let player_item = ''; //プレイヤーの駒色

	if(player_color == '白') {
		player_item = 'white';
	} else {
		player_item = 'black';
	}

	let count = 1;

	//プレイヤーの駒の数分ループ
	while(count <= ITEM_NUM) {
		element = document.getElementById(player_item + '_item_' + count);
		element.style.cursor = 'default';
		element.onclick = new Function("");

		count = count + 1;
	}

}

//動かす駒を選択後の処理
function moveBefore(position_num) {
	select_item_pos = position_num;

	//移動できる箇所が保存されている場合リセット
	if(move_pos_array.length > 0) {
		move_pos_array = [];
	}

	//プレイヤーの取られた駒がある状態で他の駒を選択していないかの判定
	if(!(player_standby > 0 && position_num > -1)) {

		//サイコロの数1つで進める箇所の登録
		if(DICE_LIST[0] > 0) {
			checkMove(position_num + DICE_LIST[0]);
		}

		if(DICE_LIST[1] > 0) {
			checkMove(position_num + DICE_LIST[1]);
		}

		//取られている駒が複数ないかの判定
		if(player_standby < 2) {

			//サイコロの数が2つ以上残っているかの判定
			if(DICE_LIST[0] > 0 && DICE_LIST[1] > 0) {

				//残っているサイコロの数がゾロ目であるかで分岐
				if(DICE_LIST[0] == DICE_LIST[1]) {
					let move_bool = false;
					let check_length = move_pos_array.length;
					let count = 2;

					//サイコロの数1つで進める箇所があるかの判定
					if(check_length > 0) {
						move_bool = true;
					}

					//同時に進行できるサイコロの数分ループ
					while(move_bool) {
						checkMove(position_num + (DICE_LIST[0] * count));

						//ループ終了条件の判定
						if(count >= DICE_LIST.length || move_pos_array.length == check_length || DICE_LIST[count] <= 0) {
							move_bool = false;
						} else {
							check_length = move_pos_array.length;
							count = count + 1;
						}

					}

				} else {

					//1箇所でも駒を進められるかの判定
					if(move_pos_array.length > 0) {
						checkMove(position_num + DICE_LIST[0] + DICE_LIST[1]);
					}

				}

			}

		}

	}

	//進行できるマスを選択可能状態に設定
	setSquare();
}

//指定された箇所に駒が進めるか判別し登録を行う
function checkMove(move_num) {
	let check_move = false; //登録可否判定用変数

	//ゴールにたどり着くかの判定
	if(move_num >= ITEM_POSITION.length) {
		check_move = true;
	} else {

		//進行先に相手の駒があるかの確認
		if(ITEM_POSITION[move_num].startsWith(enemy_color)) {

			//相手の駒が1個であるかの確認
			if(ITEM_POSITION[move_num] == enemy_color + '1') {
				check_move = true;
			}

		} else {
			check_move = true;
		}

	}

	//指定された箇所に駒が進めるかの判別
	if(check_move) {
		let insert_num = move_num;

		//ゴールにたどり着くかの判定
		if(insert_num >= ITEM_POSITION.length) {
			let gole_possible = true;
			let count = 0;

			//ゴール不可能範囲でループ
			while(count < ITEM_POSITION.length * (3 / 4)) {

				//ゴール不可能範囲にプレイヤーの駒があるかの判定
				if(ITEM_POSITION[count].startsWith(player_color)) {
					gole_possible = false;
					break;
				}

				count = count + 1;
			}

			//ゴールに駒を進められるかの判定
			if(gole_possible) {
				insert_num = 24;
			} else {
				return;
			}

		}

		//配列に指定箇所が既に登録されていない場合に登録
		if(move_pos_array.indexOf(insert_num) == -1) {
			move_pos_array.push(insert_num);
		}

	}

}

//サイコロの数で進める箇所が1つでもあるかを確認
function allMoveCheck() {
	let move_bool = false; //動かせる駒があるかの判定用
	let gole_possible = true; //ゴール可能であるかの判定用
	let count = 0;

	//ターンプレイヤーの取られた駒があるかの判定
	if(player_turn && player_standby > 0) {

		//1つ目のサイコロの数での進行先を判定
		if(DICE_LIST[0] > 0) {

			if(!ITEM_POSITION[DICE_LIST[0] - 1].startsWith(enemy_color)) {
				move_bool = true;
			} else if(ITEM_POSITION[DICE_LIST[0] - 1] == enemy_color + '1') {
				move_bool = true;
			}

		}

		//2つ目のサイコロの数での進行先を判定
		if(DICE_LIST[1] > 0 && DICE_LIST[1] != DICE_LIST[0]) {

			if(!ITEM_POSITION[DICE_LIST[1] - 1].startsWith(enemy_color)) {
				move_bool = true;
			} else if(ITEM_POSITION[DICE_LIST[1] - 1] == enemy_color + '1') {
				move_bool = true;
			}

		}

	} else if(!player_turn && enemy_standby > 0) {

		//1つ目のサイコロの数での進行先を判定
		if(DICE_LIST[0] > 0) {

			if(!ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[0]].startsWith(player_color)) {
				move_bool = true;
			} else if(ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[0]] == player_color + '1') {
				move_bool = true;
			}

		}

		//2つ目のサイコロの数での進行先を判定
		if(DICE_LIST[1] > 0 && DICE_LIST[1] != DICE_LIST[0]) {

			if(!ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[1]].startsWith(player_color)) {
				move_bool = true;
			} else if(ITEM_POSITION[ITEM_POSITION.length - DICE_LIST[1]] == player_color + '1') {
				move_bool = true;
			}

		}

	} else if(player_turn) {

		//ゴール不可能範囲でループ
		while(count < ITEM_POSITION.length * (3 / 4)) {

			//ゴール不可能範囲に対応の駒があるかの判定
			if(ITEM_POSITION[count].startsWith(player_color)) {
				gole_possible = false;
				break;
			}

			count = count + 1;
		}

		count = 0;

		//盤面のマス数だけループ
		while(count < ITEM_POSITION.length) {

			//チェックする駒があるマスを判定
			if(ITEM_POSITION[count].startsWith(player_color)) {

				//1つ目のサイコロの数でゴールにたどり着くかの判定
				if(count + DICE_LIST[0] >= ITEM_POSITION.length) {

					if(gole_possible) {
						move_bool = true;
						break;
					}

				} else {

					//進行先に相手の駒がないかの判定
					if(DICE_LIST[0] != 0) {

						if(!ITEM_POSITION[count + DICE_LIST[0]].startsWith(enemy_color)) {
							move_bool = true;
							break;
						} else if(ITEM_POSITION[count + DICE_LIST[0]] == enemy_color + '1') {
							move_bool = true;
							break;
						}

					}

				}

				//2つ目のサイコロの数でゴールにたどり着くかの判定
				if(count + DICE_LIST[1] >= ITEM_POSITION.length) {

					if(gole_possible) {
						move_bool = true;
						break;
					}

				} else {

					//進行先に相手の駒がないかの判定
					if(DICE_LIST[1] != 0) {

						if(!ITEM_POSITION[count + DICE_LIST[1]].startsWith(enemy_color)) {
							move_bool = true;
							break;
						} else if(ITEM_POSITION[count + DICE_LIST[1]] == enemy_color + '1') {
							move_bool = true;
							break;
						}

					}

				}

			}

			count = count + 1;
		}

	} else {
		count = ITEM_POSITION.length / 4;

		//ゴール不可能範囲でループ
		while(count < ITEM_POSITION.length) {

			//ゴール不可能範囲に対応の駒があるかの判定
			if(ITEM_POSITION[count].startsWith(enemy_color)) {
				gole_possible = false;
				break;
			}

			count = count + 1;
		}

		count = 0;

		//盤面のマス数だけループ
		while(count < ITEM_POSITION.length) {

			//チェックする駒があるマスを判定
			if(ITEM_POSITION[count].startsWith(enemy_color)) {

				//1つ目のサイコロの数でゴールにたどり着くかの判定
				if(count - DICE_LIST[0] < 0) {

					if(gole_possible) {
						move_bool = true;
						break;
					}

				} else {

					//進行先に相手の駒がないかの判定
					if(DICE_LIST[0] != 0) {

						if(!ITEM_POSITION[count - DICE_LIST[0]].startsWith(player_color)) {
							move_bool = true;
							break;
						} else if(ITEM_POSITION[count - DICE_LIST[0]] == player_color + '1') {
							move_bool = true;
							break;
						}

					}

				}

				//2つ目のサイコロの数でゴールにたどり着くかの判定
				if(count - DICE_LIST[1] < 0) {

					if(gole_possible) {
						move_bool = true;
						break;
					}

				} else {

					//進行先に相手の駒がないかの判定
					if(DICE_LIST[1] != 0) {

						if(!ITEM_POSITION[count - DICE_LIST[1]].startsWith(player_color)) {
							move_bool = true;
							break;
						} else if(ITEM_POSITION[count - DICE_LIST[1]] == player_color + '1') {
							move_bool = true;
							break;
						}

					}

				}

			}

			count = count + 1;
		}

	}

	return move_bool;
}

//駒の進行処理
function moveAfter(move_num) {
	//指定された場所への移動が可能かの判定
	let delete_bool = false;

	//どちらの駒を処理するかの判定
	if(player_turn) {
		delete_bool = deleteDice(move_num);
	} else {
		delete_bool = enemyDeleteDice(move_num);
	}

	//移動可能判定
	if(delete_bool) {
		let item_color = ''; //動かす駒の色

		//駒の色の判定
		if(player_turn) {
			item_color = player_color;
		} else {
			item_color = enemy_color;
		}

		//移動元の変更
		if(player_standby > 0 && player_turn) {
			player_standby = player_standby - 1;
		} else if(enemy_standby > 0 && !player_turn) {
			enemy_standby = enemy_standby - 1;
		} else if(ITEM_POSITION[select_item_pos] == item_color + 1) {
			ITEM_POSITION[select_item_pos] = '';
		} else {
			ITEM_POSITION[select_item_pos] = item_color +
				(Number(ITEM_POSITION[select_item_pos].slice(1, ITEM_POSITION[select_item_pos].length)) - 1);
		}

		//移動先の変更
		if(move_num >= SQU_NUM && player_turn) {
			player_gole = player_gole + 1;
		} else if(move_num < 0 && !player_turn) {
			enemy_gole = enemy_gole + 1;
		} else if(ITEM_POSITION[move_num] == '') {
			ITEM_POSITION[move_num] = item_color + 1;
		} else if(ITEM_POSITION[move_num].startsWith(item_color)) {
			ITEM_POSITION[move_num] = item_color +
				(Number(ITEM_POSITION[move_num].slice(1, ITEM_POSITION[move_num].length)) + 1);
		} else {
			ITEM_POSITION[move_num] = item_color + 1;

			if(player_turn) {
				enemy_standby = enemy_standby + 1;
			} else {
				player_standby = player_standby + 1;
			}

		}

		//表示の設定
		resetSquare();
		setItemPosition();
		setDicePosition('standby');
		cursorOn();

		//選択している駒のリセット
		select_item_pos = -1;
		let turn_finish = true;
		let count = 0;

		//駒を動かし切ったかの判定
		while(count < DICE_LIST.length) {

			if(DICE_LIST[count] != 0) {
				turn_finish = false;
			}

			count = count + 1;
		}

		//ゲームの終了、自分ターンの終了、または残っているサイコロの数で動かせる駒の確認
		if(player_gole >= ITEM_NUM || enemy_gole >= ITEM_NUM) {
			gameFinish();
		} else if(turn_finish) {
			player_turn = false;
			cursorOff();
		} else if(!allMoveCheck()) {
			playerStop();
			cursorOff();
		}

	} else {
		alert('駒の移動ができません');
	}

}

//プレイヤーの駒の移動可否を判定し、使用したサイコロの数を削除
function deleteDice(move_num) {
	const MOVE_RANGE = move_num - select_item_pos;
	let delete_bool = false;
	let count = 0;

	//進行箇所がゴールであるかの判定
	if(move_num >= SQU_NUM) {
		let gole_possible = true;

		//ゴール不可能範囲でループ
		while(count < ITEM_POSITION.length * (3 / 4)) {

			////ゴール不可能範囲にプレイヤーの駒があるかの判定
			if(ITEM_POSITION[count].startsWith(player_color)) {
				gole_possible = false;
			}

			count = count + 1;
		}

		//ゴールに駒を進められるかの判定
		if(gole_possible) {

			//ゾロ目であるかどうかの判定
			if(DICE_LIST[0] == DICE_LIST[1]) {
				let delete_count = 0;
				let index = DICE_LIST.length - 1;

				//ゴールまでにサイコロ何個分が必要かを判定
				if(DICE_LIST[0] >= MOVE_RANGE) {
					delete_count = 1;
				} else if(DICE_LIST[0] * 2 >= MOVE_RANGE) {
					delete_count = 2;
				} else if(DICE_LIST[0] * 3 >= MOVE_RANGE) {
					delete_count = 3;
				} else {
					delete_count = 4;
				}

				//使用分のサイコロの数を削除するまでループ
				while(delete_count > 0 && index >= 0) {

					if(DICE_LIST[index] > 0) {
						DICE_LIST[index] = 0;
						delete_count = delete_count - 1;
					}

					index = index - 1;
				}

				//正常に削除できたかの判定
				if(delete_count == 0) {
					delete_bool = true;
				}

			} else {

				//サイコロの数が小さいほうから処理を行う
				if(DICE_LIST[0] < DICE_LIST[1]) {

					//進行する数以上になるようにサイコロの数を使用し削除
					if(DICE_LIST[0] >= MOVE_RANGE) {
						DICE_LIST[0] = 0;
						delete_bool = true;
					} else if(DICE_LIST[1] >= MOVE_RANGE) {
						DICE_LIST[1] = 0;
						delete_bool = true;
					} else if(DICE_LIST[0] + DICE_LIST[1] >= MOVE_RANGE) {
						DICE_LIST[0] = 0;
						DICE_LIST[1] = 0;
						delete_bool = true;
					}

				} else {

					//進行する数以上になるようにサイコロの数を使用し削除
					if(DICE_LIST[1] >= MOVE_RANGE) {
						DICE_LIST[1] = 0;
						delete_bool = true;
					} else if(DICE_LIST[0] >= MOVE_RANGE) {
						DICE_LIST[0] = 0;
						delete_bool = true;
					} else if(DICE_LIST[0] + DICE_LIST[1] >= MOVE_RANGE) {
						DICE_LIST[0] = 0;
						DICE_LIST[1] = 0;
						delete_bool = true;
					}

				}

			}

		}

	} else {
		count = DICE_LIST.length - 1;

		//使用したサイコロの数を削除
		while(count >= 0) {

			if(DICE_LIST[count] == MOVE_RANGE) {
				DICE_LIST[count] = 0;
				delete_bool = true;
				break;
			}

			count = count - 1;
		}

		//削除ができていない場合、複数の数を使用している場合を確認
		if(!delete_bool) {

			//数が重複していないかで分岐
			if(DICE_LIST[0] != DICE_LIST[1]) {

				if(DICE_LIST[0] + DICE_LIST[1] == MOVE_RANGE) {
					DICE_LIST[0] = 0;
					DICE_LIST[1] = 0;
					delete_bool = true;
				}

			} else {
				let move_count = 0;

				if(DICE_LIST[0] * 4 == MOVE_RANGE) {
					move_count = 4;
				} else if(DICE_LIST[0] * 3 == MOVE_RANGE) {
					move_count = 3;
				} else if(DICE_LIST[0] * 2 == MOVE_RANGE) {
					move_count = 2;
				}

				//サイコロの数を足した数のマスが選択されているかの判定
				if(move_count != 0) {
					let sub_count = DICE_LIST.length - 1;

					//サイコロの数分ループ
					while(sub_count >= 0) {

						//数字が登録されているかの確認
						if(DICE_LIST[sub_count] != 0) {
							DICE_LIST[sub_count] = 0;
							move_count = move_count - 1;
						}

						//移動した分のサイコロの数字を削除したかの確認
						if(move_count == 0) {
							sub_count = -1;
						} else {
							sub_count = sub_count - 1;
						}

					}

					//サイコロの数の削除が正常に終了したかの判定
					if(move_count == 0) {
						delete_bool = true;
					} else {
						alert('マスの移動処理を正常に行えませんでした');
					}

				}

			}

		}

	}

	return delete_bool;
}

//相手の駒の移動可否を判定し、使用したサイコロの数を削除(相手の移動は1つずつ行うので2つ以上同時に動かす場合は考えない)
function enemyDeleteDice(move_num) {
	const MOVE_RANGE = select_item_pos - move_num;
	let delete_bool = false;
	let count = ITEM_POSITION.length / 4;

	//進行箇所がゴールであるかの判定
	if(move_num < 0) {
		let gole_possible = true;

		//ゴール不可能範囲でループ
		while(count < ITEM_POSITION.length) {

			////ゴール不可能範囲に相手の駒があるかの判定
			if(ITEM_POSITION[count].startsWith(enemy_color)) {
				gole_possible = false;
			}

			count = count + 1;
		}

		//ゴールに駒を進められるかの判定
		if(gole_possible) {

			//ゾロ目であるかどうかの判定
			if(DICE_LIST[0] == DICE_LIST[1]) {
				let index = DICE_LIST.length - 1;

				//削除できるサイコロの数までループ
				while(index >= 0) {

					if(DICE_LIST[index] > 0) {
						DICE_LIST[index] = 0;
						delete_bool = true;
						break;
					}

					index = index - 1;
				}

			} else {

				//サイコロの数が小さいほうから処理を行う
				if(DICE_LIST[0] < DICE_LIST[1]) {

					//進行する数以上になるようにサイコロの数を使用し削除
					if(DICE_LIST[0] >= MOVE_RANGE) {
						DICE_LIST[0] = 0;
						delete_bool = true;
					} else if(DICE_LIST[1] >= MOVE_RANGE) {
						DICE_LIST[1] = 0;
						delete_bool = true;
					}

				} else {

					//進行する数以上になるようにサイコロの数を使用し削除
					if(DICE_LIST[1] >= MOVE_RANGE) {
						DICE_LIST[1] = 0;
						delete_bool = true;
					} else if(DICE_LIST[0] >= MOVE_RANGE) {
						DICE_LIST[0] = 0;
						delete_bool = true;
					}

				}

			}

		}

	} else {
		count = DICE_LIST.length - 1;

		//使用したサイコロの数を削除
		while(count >= 0) {

			if(DICE_LIST[count] == MOVE_RANGE) {
				DICE_LIST[count] = 0;
				delete_bool = true;
				break;
			}

			count = count - 1;
		}

	}

	return delete_bool;
}

//動かせる駒がない時の処理
function playerStop() {
	//表示設定
	setDicePosition('standby');

	//テキスト設定
	let element = document.getElementById('text_message');
	element.style.display = 'block';
	element.style.top = TEXT_TOP + 'px';
	element.style.left = TEXT_LEFT + 'px';

	element = document.getElementById('message_img');
	element.src = IMG_FILES + 'テキスト_ターンスキップ.png';

	//ボタン設定
	element = document.getElementById('play_ok');
	element.style.display = 'block';

	element = document.getElementById('play_ok_click');
	element.onclick = new Function("playBackgammon('enemy_turn')");
}

//勝利条件の確認
function gameFinish() {

	//どちらかの駒がすべてゴールに入っているかの判別
	if(player_gole >= ITEM_NUM || enemy_gole >= ITEM_NUM) {
		sleep(1000);

		//使わない表示のリセット
		resetSquare();
		resetBotton();

		let element = document.getElementById('text_message');
		element.style.display = 'block';
		element.style.top = (TEXT_TOP - 50) + 'px';
		element.style.left = TEXT_LEFT + 'px';

		//プレイヤーの勝敗確認
		if(player_gole >= ITEM_NUM) {
			element = document.getElementById('message_img');
			element.src = IMG_FILES + 'テキスト_プレイヤー勝利.png';
		} else if(enemy_gole >= ITEM_NUM){
			element = document.getElementById('message_img');
			element.src = IMG_FILES + 'テキスト_プレイヤー敗北.png';
		}

	}

}