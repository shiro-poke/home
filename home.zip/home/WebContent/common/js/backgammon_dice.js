//バックギャモン：サイコロの処理

//ゲーム開始時のサイコロ表示
function startDice() {
	//表示のリセット
	resetDice();
	resetBotton();
	resetText();

	//ボタンの表示
	element = document.getElementById('play_dice');
	element.style.display = 'block';

	//サイコロの表示
	DICE_LIST[0] = 1;
	DICE_LIST[1] = 0;
	DICE_LIST[2] = 0;
	DICE_LIST[3] = 0;
	setDicePosition('start');
}

//サイコロの処理
function playDice() {
	let element = null; //IDの取得用変数
	let count = 0;
	dice_num_1 = randomDice(); //1つ目のサイコロの目
	dice_num_2 = randomDice(); //2つ目のサイコロの目

	//保存されているサイコロの数のリセット
	while(count < DICE_LIST.length) {
		DICE_LIST[count] = 0;
		count = count + 1;
	}

	//ボタンの表示
	element = document.getElementById('play_dice');
	element.style.display = 'none';

	//ゲームが開始されているかの判定
	if(play_game) {

		//ゾロ目であるかの判定
		if(dice_num_1 == dice_num_2) {
			//サイコロの値をリストに保存
			DICE_LIST[0] = dice_num_1;
			DICE_LIST[1] = dice_num_1;
			DICE_LIST[2] = dice_num_1;
			DICE_LIST[3] = dice_num_1;
		} else {
			//サイコロの値をリストに保存
			DICE_LIST[0] = dice_num_1;
			DICE_LIST[1] = dice_num_2;
		}

		setDicePosition('center');

		if(player_turn) {

			//出たサイコロの数で駒を動かせるかの判定
			if(allMoveCheck()) {
				element = document.getElementById('play_ok');
				element.style.display = 'block';

				element = document.getElementById('play_ok_click');
				element.onclick = new Function("playBackgammon('player_turn')");
			} else {
				playerStop();
			}

		}

	} else {
		DICE_LIST[0] = dice_num_1;
		DICE_LIST[1] = dice_num_2;

		//サイコロの表示
		resetGame();
		setDicePosition('start');

		//テキスト表示
		element = document.getElementById('text_player');
		element.style.display = 'block';
		element.style.top = (DICE_TOP_CENTER - 70) + 'px';
		element.style.left = (DICE_LEFT_CENTER - (DICE_SIZE + 40)) + 'px';

		element = document.getElementById('text_enemy');
		element.style.display = 'block';
		element.style.top = (DICE_TOP_CENTER - 70) + 'px';
		element.style.left = (DICE_LEFT_CENTER + (DICE_SIZE - 10)) + 'px';

		element = document.getElementById('text_message');
		element.style.display = 'block';
		element.style.top = TEXT_TOP + 'px';
		element.style.left = TEXT_LEFT + 'px';

		//サイコロの目が同じであるかの判定
		if(dice_num_1 == dice_num_2) {
			element = document.getElementById('message_img');
			element.src = IMG_FILES + 'テキスト_振り直し.png';

			element = document.getElementById('play_ok');
			element.style.display = 'block';

			element = document.getElementById('play_ok_click');
			element.onclick = new Function("playBackgammon('start')");
		} else {

			//サイコロの目の大小を比較
			if(dice_num_1 > dice_num_2) {
				element = document.getElementById('message_img');
				element.src = IMG_FILES + 'テキスト_プレイヤー先攻.png';

				element = document.getElementById('play_ok');
				element.style.display = 'block';

				element = document.getElementById('play_ok_click');
				element.onclick = new Function("playBackgammon('set_position')");

				turn_order = true;
				player_color = '白';
				enemy_color = '黒';
			} else {
				element = document.getElementById('message_img');
				element.src = IMG_FILES + 'テキスト_相手先攻.png';

				element = document.getElementById('play_ok');
				element.style.display = 'block';

				element = document.getElementById('play_ok_click');
				element.onclick = new Function("playBackgammon('set_position')");

				turn_order = false;
				player_color = '黒';
				enemy_color = '白';
				enemy_move = 2;
			}

		}

	}

}

//サイコロの表示設定
function setDicePosition(type) {
	let element = null;
	let count = 0;
	let dice_count = 0;

	//サイコロ表示のリセット
	resetDice();

	//サイコロの数だけループ
	while(count < DICE_LIST.length) {

		//サイコロの値があるかの判別
		if(DICE_LIST[count] > 0) {
			dice_count = dice_count + 1;
			element = document.getElementById('dice_img_' + dice_count);
			element.src = IMG_FILES + 'サイコロ_' + DICE_LIST[count] + '.png';
		}

		count = count + 1;
	}

	const SET_DICE = dice_count;

	//サイコロの数により表示位置を調整
	switch(SET_DICE) {
		case 1:

			//受け取った設置タイプにより分岐
			if(type == 'start') {
				element = document.getElementById('dice_1');
				element.style.display = 'block';
				element.style.top = DICE_TOP_CENTER + 'px';
				element.style.left = DICE_LEFT_CENTER + 'px';
			} else if(type == 'standby') {
				element = document.getElementById('dice_1');
				element.style.display = 'block';
				element.style.top = DICE_TOP_STANDBY + 'px';
				element.style.left = DICE_LEFT_STANDBY + 'px';
			}

			break;
		case 2:

			if(type == 'start') {
				element = document.getElementById('dice_1');
				element.style.display = 'block';
				element.style.top = DICE_TOP_CENTER + 'px';
				element.style.left = (DICE_LEFT_CENTER - (DICE_SIZE + 5)) + 'px';

				element = document.getElementById('dice_2');
				element.style.display = 'block';
				element.style.top = DICE_TOP_CENTER + 'px';
				element.style.left = (DICE_LEFT_CENTER + (DICE_SIZE + 5)) + 'px';
			} else if(type == 'center') {
				element = document.getElementById('dice_1');
				element.style.display = 'block';
				element.style.top = DICE_TOP_CENTER + 'px';
				element.style.left = (DICE_LEFT_CENTER - ((DICE_SIZE + 5) * (1 / 2))) + 'px';

				element = document.getElementById('dice_2');
				element.style.display = 'block';
				element.style.top = DICE_TOP_CENTER + 'px';
				element.style.left = (DICE_LEFT_CENTER + ((DICE_SIZE + 5) * (1 / 2))) + 'px';
			} else if(type == 'standby') {
				element = document.getElementById('dice_1');
				element.style.display = 'block';
				element.style.top = DICE_TOP_STANDBY + 'px';
				element.style.left = (DICE_LEFT_STANDBY - ((DICE_SIZE + 5) / 2)) + 'px';

				element = document.getElementById('dice_2');
				element.style.display = 'block';
				element.style.top = DICE_TOP_STANDBY + 'px';
				element.style.left = (DICE_LEFT_STANDBY + ((DICE_SIZE + 5) / 2)) + 'px';
			}

			break;
		case 3:

			if(type == 'standby') {
				element = document.getElementById('dice_1');
				element.style.display = 'block';
				element.style.top = (DICE_TOP_STANDBY - ((DICE_SIZE + 5) / 2)) + 'px';
				element.style.left = (DICE_LEFT_STANDBY - ((DICE_SIZE + 5) / 2)) + 'px';

				element = document.getElementById('dice_2');
				element.style.display = 'block';
				element.style.top = (DICE_TOP_STANDBY - ((DICE_SIZE + 5) / 2)) + 'px';
				element.style.left = (DICE_LEFT_STANDBY + ((DICE_SIZE + 5) / 2)) + 'px';

				element = document.getElementById('dice_3');
				element.style.display = 'block';
				element.style.top = (DICE_TOP_STANDBY + ((DICE_SIZE + 5) / 2)) + 'px';
				element.style.left = DICE_LEFT_STANDBY + 'px';
			}

			break;
		case 4:

			if(type == 'center') {
				element = document.getElementById('dice_1');
				element.style.display = 'block';
				element.style.top = DICE_TOP_CENTER + 'px';
				element.style.left = (DICE_LEFT_CENTER - ((DICE_SIZE + 5) * (3 / 2))) + 'px';

				element = document.getElementById('dice_2');
				element.style.display = 'block';
				element.style.top = DICE_TOP_CENTER + 'px';
				element.style.left = (DICE_LEFT_CENTER - (DICE_SIZE + 5) * (1 / 2)) + 'px';

				element = document.getElementById('dice_3');
				element.style.display = 'block';
				element.style.top = DICE_TOP_CENTER + 'px';
				element.style.left = (DICE_LEFT_CENTER + (DICE_SIZE + 5) * (1 / 2)) + 'px';

				element = document.getElementById('dice_4');
				element.style.display = 'block';
				element.style.top = DICE_TOP_CENTER + 'px';
				element.style.left = (DICE_LEFT_CENTER + ((DICE_SIZE + 5)  * (3 / 2))) + 'px';
			} else if(type == 'standby') {
				element = document.getElementById('dice_1');
				element.style.display = 'block';
				element.style.top = (DICE_TOP_STANDBY - (DICE_SIZE + 5) / 2) + 'px';
				element.style.left = (DICE_LEFT_STANDBY - ((DICE_SIZE + 5) / 2)) + 'px';

				element = document.getElementById('dice_2');
				element.style.display = 'block';
				element.style.top = (DICE_TOP_STANDBY - (DICE_SIZE + 5) / 2) + 'px';
				element.style.left = (DICE_LEFT_STANDBY + ((DICE_SIZE + 5) / 2)) + 'px';

				element = document.getElementById('dice_3');
				element.style.display = 'block';
				element.style.top = (DICE_TOP_STANDBY + (DICE_SIZE + 5) / 2) + 'px';
				element.style.left = (DICE_LEFT_STANDBY - ((DICE_SIZE + 5) / 2)) + 'px';

				element = document.getElementById('dice_4');
				element.style.display = 'block';
				element.style.top = (DICE_TOP_STANDBY + (DICE_SIZE + 5) / 2) + 'px';
				element.style.left = (DICE_LEFT_STANDBY + ((DICE_SIZE + 5) / 2)) + 'px';
			}

			break;
		default:
	}

}

//1～6までの乱数を1つ作成
function randomDice() {
	return Math.floor(Math.random() * 6) + 1;
}
