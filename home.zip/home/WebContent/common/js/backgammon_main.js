//バックギャモン：メインファイル

//自動で行う処理
window.onload = function() {
	setInterval(function(){enemyMove()}, 1);
	setInterval(function(){gameFinish()}, 1);

	//画像の読み込み
	loadComplete();
};

function test() {/////////////////////////////////////////////////////////テスト
	resetDice();
	resetBotton();
	let element = document.getElementById('gole_poket');
	element.style.display = 'block';
	element.style.top = GOLE_TOP_SQU + 'px';
	element.style.left = GOLE_LEFT_SQU + 'px';
	element.style.cursor = 'pointer';
}

//ボタン入力時の処理
function playBackgammon(input_val) {
	const INPUT = String(input_val); //受け取った入力をString型に変換

	//受け取った入力により実行する処理を分岐
	switch(INPUT) {
		case 'start': //ゲームの開始
			play_game = false;
			startDice();
			break;
		case 'dice': //サイコロを振る
			playDice();
			break;
		case 'set_position': //駒の初期配置
			startPosition();
		case 'player_turn': //プレイヤーのターン開始
			setItemPosition();
			setDicePosition('standby');
			resetBotton();
			break;
		case 'enemy_turn': //相手のターン開始
			player_turn = false;
			cursorOff();
			resetDice();
			resetBotton();
			resetText();
			break;
		case 'reset_select':

			if(player_turn) {
				resetSquare();
			}

			break;
		default: //番号を受け取って行う処理、またはエラー

			if(INPUT.startsWith('select_item_') &&
			   (Number(INPUT.slice(12, INPUT.length)) >= -1 && Number(INPUT.slice(12, INPUT.length)) <= 23)) { //駒の進行範囲確認
				moveBefore(Number(INPUT.slice(12, INPUT.length)));
			} else if(INPUT.startsWith('select_square_') &&
			   (Number(INPUT.slice(14, INPUT.length)) >= 0 && Number(INPUT.slice(14, INPUT.length)) <= 24)) { //駒の進行処理
			   moveAfter(Number(INPUT.slice(14, INPUT.length)));
			} else { //エラー
				alert('予期せぬ値「' + INPUT + '」が入力されました');
				return;
			}

	}

	//画像の読み込み
	loadComplete();
}

//画面表示のリセット
function resetGame() {
	resetSquare(); //進行可能マス
	resetItem(); //駒
	resetDice(); //サイコロ
	resetBotton(); //ボタン
	resetText(); //テキスト
}

//進行可能マスのリセット
function resetSquare() {
	let element = null;
	let count = 1;

	//マスの総数分ループ
	while(count <= SQU_NUM) {
		element = document.getElementById('square_' + count);
		element.style.display = 'none';

		count = count + 1;
	}

	element = document.getElementById('gole_poket');
	element.style.display = 'none';
}

//駒のリセット
function resetItem() {
	let element = null;
	let count = 1;

	//各色の駒の個数分ループ
	while(count <= ITEM_NUM) {
		element = document.getElementById('black_item_' + count);
		element.style.display = 'none';

		element = document.getElementById('white_item_' + count);
		element.style.display = 'none';

		count = count + 1;
	}

}

//サイコロのリセット
function resetDice() {
	let element = null;
	let count = 1;

	//保存できるサイコロの数分ループ
	while(count <= DICE_NUM) {
		element = document.getElementById('dice_' + count);
		element.style.display = 'none';

		count = count + 1;
	}

}

//ボタンのリセット
function resetBotton() {
	let element = null;

	element = document.getElementById('play_start');
	element.style.display = 'none';

	element = document.getElementById('play_dice');
	element.style.display = 'none';

	element = document.getElementById('play_ok');
	element.style.display = 'none';
}

//テキストのリセット
function resetText() {
	let element = null;

	element = document.getElementById('text_player');
	element.style.display = 'none';

	element = document.getElementById('text_enemy');
	element.style.display = 'none';

	element = document.getElementById('text_message');
	element.style.display = 'none';
}

//指定したミリ秒処理を待機させる
function sleep(milli_time) {
	let now_date = new Date(); //現在の日時データ

	//指定したミリ秒経過までループ
	while(new Date - now_date < milli_time) {
	}

}

//画像のロード完了まで待機させる           ////////////////ほぼコピペなので機能がわからない(意図した機能になっていない)
function loadComplete() {
	let img_element = document.querySelectorAll('img');
	load_count = 0;

	while(load_count < img_element.length) {
		img_element[i].addEventListener('load', loadCount());
	}

}

//画像読み込みのカウントを進める
function loadCount() {
	load_count = load_count + 1
}
