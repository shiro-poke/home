let result_val = '0'; //計算結果の値
let holder_val = '　'; //計算待機中の値
let input_block = true; //計算途中判定用
let hold_cal = ''; //待機中の計算の種類保持
let play_special = false; //特殊処理実行確認用

//電卓の処理
function playCal(input_val) {
	const INPUTCHECK = String(input_val); //取得した値をstring型に統一

	//入力したボタンによる条件分岐
	switch(INPUTCHECK) {
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
		case '0':
		case '.':
			inputNum(INPUTCHECK); //①メソッドの実行(値の入力)
			break;
		case '＋':
		case '－':
		case '×':
		case '÷':
		case '＝':
			inputCal(INPUTCHECK); //②メソッドの実行(計算の実行)
			break;
		case '%':
		case 'CE':
		case 'C':
		case 'BACK':
		case '+/-':
		case '1/x':
		case 'x²':
		case '²√x':
			specialCal(INPUTCHECK) //③メソッドの実行(特殊処理の実行)
			break;
		default:
			//エラー表示の設定
			holder_val = '　';
			result_val = '予期せぬ処理が入力されました';
			hold_cal = '';
			play_special = false;
	}

	//画面表示の設定
	document.getElementById('holder').innerHTML = holder_val;
	document.getElementById('result').innerHTML = result_val;
}


//値入力の処理----------------------------------------------------------------------------------------------①
function inputNum(input_val) {
	const VALCHECK = String(input_val); //取得した値をstring型に統一

	//指定された値以外が渡された場合エラーを返す
	switch(VALCHECK) {
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
		case '0':
		case '.':
			break;
		default:
			holder_val = '　';
			result_val = '予期せぬ値が入力されました';
			hold_cal = '';
			play_special = false;
	}

	//エラー表示中の場合は処理を中断
	if(String(Number(result_val)) == 'NaN') {
		return;
	}

	//入力した値が頭であるかの判定
	if(input_block) {

		//計算終了後に値を入力した場合結果をリセット
		//分数、累乗、平方根も計算の区切りとする
		if(holder_val == '　' || play_special) {
			result_val = '0';
			play_special = false;
		}

		//入力した値による分岐
		switch(VALCHECK) {
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
			case '0':
				result_val = VALCHECK;
				input_block = false;
				break;
			case '.':

				//小数点がすでに使われていないかの確認
				if(!(VALCHECK == '.' && result_val.indexOf('.') != -1)) {
					result_val = result_val + VALCHECK;
					input_block = false;
				}

				break;
		}

	} else {

		//入力した値による分岐
		switch(VALCHECK) {
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':

				//表示が0以外であるかの判定
				if(result_val != '0') {
					result_val = result_val + VALCHECK;
				} else {
					result_val = VALCHECK;
				}

				break;
			case '0':

				//表示が0以外であるかの判定
				if(result_val != '0') {
					result_val = result_val + VALCHECK;
				}

				break;
			case '.':

				//現在の値が0(小数点以下入力待機状態以外)であるかの判定
				if(result_val == '0' && VALCHECK != '.') {
					result_val = VALCHECK;
				} else {

					//小数点がすでに使われていないかの確認
					if(!(VALCHECK == '.' && result_val.indexOf('.') != -1)) {
						result_val = result_val + VALCHECK;
					}

				}

				break;
		}

	}

}

//計算演算子入力時の処理------------------------------------------------------------------------------------②
function inputCal(input_val) {
	const INPUTCHECK = String(input_val); //取得した値をstring型に統一
	play_special = false;

	//指定された値以外が渡された場合にエラーを返す
	switch(INPUTCHECK) {
		case '＋':
		case '－':
		case '×':
		case '÷':
		case '＝':
			break;
		default:
			holder_val = '　';
			result_val = '予期せぬ処理が入力されました';
			hold_cal = '';
			play_special = false;
	}

	//エラー表示中の場合に処理を中断
	if(String(Number(result_val)) == 'NaN') {
		return;
	}

	//待機中の計算がないかの判定
	if(hold_cal == '') {

		//入力していた演算子による分岐
		switch(INPUTCHECK) {
			case '＋':
			case '－':
			case '×':
			case '÷':
				holder_val = remakeNum(result_val) + ' ' + INPUTCHECK;
				result_val = '0';
				hold_cal = INPUTCHECK;
				break;
			case '＝':
		}

	} else {
		const HOLDCHECK = String(hold_cal); //取得した待機中の処理をstring型に統一

		//処理待機中の演算子による分岐
		switch(HOLDCHECK) {
			case '＋':
				hold_cal = String(Number(remakeNum(holder_val)) + Number(result_val));
				break;
			case '－':
				hold_cal = String(Number(remakeNum(holder_val)) - Number(result_val));
				break;
			case '×':
				hold_cal = String(Number(remakeNum(holder_val)) * Number(result_val));
				break;
			case '÷':

				//0で割っていないかの判定
				if(remakeNum(result_val) != 0) {
					hold_cal = String(Number(remakeNum(holder_val)) / Number(result_val));
				} else {
					holder_val = '　';
					result_val = '0で値を割ることはできません';
					hold_cal = '';
					play_special = false;
					return;
				}

				break;
			case '＝':
				break;
			default:
				hold_cal = 'NaN';
				break;
		}

		//計算が正常に行われたかの確認
		if(hold_cal != 'NaN') {

			//入力が計算の演算子であるかの確認
			if(INPUTCHECK != '＝') {
				holder_val = remakeNum(hold_cal) + ' ' + INPUTCHECK;
				result_val = '0';
				hold_cal = INPUTCHECK;
			} else {
				holder_val = '　';
				result_val = hold_cal;
				hold_cal = '';
			}

		} else {
			//エラー表示の設定
			holder_val = '　';
			result_val = '計算が正常に終了しませんでした';
			hold_cal = '';
			play_special = false;
		}

	}

	input_block = true;
}

//特殊処理入力時の処理--------------------------------------------------------------------------------------③
function specialCal(input_val) {
	const INPUTCHECK = String(input_val); //取得した値をstring型に統一
	play_special = false;

	//指定された値以外が渡された場合にエラーを返す
	switch(INPUTCHECK) {
		case 'C':
			holder_val = '　';
			hold_cal = '';
		case 'CE':
			//値の初期化
			result_val = '0';
			input_block = true;
			play_special = false;
			return;
		case '%':
		case 'BACK':
		case '+/-':
		case '1/x':
		case 'x²':
		case '²√x':
			break;
		default:
			holder_val = '　';
			result_val = '予期せぬ処理が入力されました';
			hold_cal = '';
			play_special = false;
	}

	//エラー表示中の場合に処理を中断
	if(String(Number(result_val)) == 'NaN') {
		return;
	}

	//入力していた処理による分岐
	switch(INPUTCHECK) {
		case '%':
			const CHECKCAL = String(hold_cal); //待機している計算演算子を取得しstring型に統一

			//待機している計算演算子により分岐
			switch(CHECKCAL) {
				case '＋':
				case '－':
					result_val = String(Number(remakeNum(holder_val)) * (Number(remakeNum(result_val)) / 100));
					break;
				case '×':
				case '÷':
				case '':
					result_val = Number(remakeNum(result_val)) / 100;
					break;
				default:
			}

			break;
		case 'BACK':

			//実行可能な状態であるかの判定
			if(!input_block) {

				//値の文字数と正負の判定
				if(result_val.length == 2 && result_val.startsWith('-')) {
					result_val = '0';
				} else if(result_val.length == 1) {
					result_val = '0';
				} else {
					result_val = result_val.slice(0, result_val.length - 1);
				}

			}

			break;
		case '+/-':

			//数字の正負の判定
			if(result_val.startsWith('-')) {
				result_val = result_val.slice(1, result_val.length);
			} else {

				//処理対象が0以外であるかの判別
				if(remakeNum(result_val) != '0') {
					result_val = '-' + result_val;
				}

			}

			break;
		case '1/x':

			//処理対象が0以外であるかの判別
			if(remakeNum(result_val) != '0') {
				result_val = String(1 / Number(remakeNum(result_val)));
				input_block = true;
				play_special = true;
			} else {
				holder_val = '　';
				result_val = '0で値を割ることはできません';
				hold_cal = '';
				play_special = false;
			}

			break;
		case 'x²':
			result_val = String(Number(remakeNum(result_val)) * Number(remakeNum(result_val)));
			input_block = true;
			play_special = true;
			break;
		case '²√x':

			//数値の正負の判定
			if(!result_val.startsWith('-')) {
				result_val = String(Math.sqrt(Number(remakeNum(result_val))));
				input_block = true;
				play_special = true;
			} else {
				holder_val = '　';
				result_val = '負の値の平方根を求めることはできません';
				hold_cal = '';
				play_special = false;
			}

			break;
	}

}

//数字表示を整える
function remakeNum(num) {
	let remake = String(num);

	////計算待機中の値の演算子を削除
	if(remake.endsWith('＋') || remake.endsWith('－') || remake.endsWith('×') || remake.endsWith('÷')) {
		remake = remake.slice(0, -2);
	}

	//末尾が小数点である場合削除
	if(remake.endsWith('.')) {
		remake = remake.slice(0, -1);
	}

	//小数点以下があるかの判定
	if(remake.indexOf('.') != -1) {

		//小数点以下の不要な0を削除
		while(remake.endsWith('0')) {
			remake = remake.slice(0, -1);
		}

	}

	//小数点以下がないのに小数点がある場合削除
	if(remake.endsWith('.')) {
		remake = remake.slice(0, -1);
	}

	return remake;
}/**
 *
 */