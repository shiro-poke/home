package action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.MakerDAO;
import dao.PlayRecodeDAO;

//異世界転生診断メーカーの処理
public class MakerResultAction extends Action {

	//アクション処理
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String result = null;

		//入力された名前を取得
		String name = (String)request.getParameter("checkName");

		//DAOクラスの準備
		MakerDAO mDao = new MakerDAO();
		PlayRecodeDAO prDao = new PlayRecodeDAO();

		//SQL処理の実行
		try {
			//最終プレイ日の確認
			boolean recodeChk = prDao.checkDate();

			//今日まだ未プレイの場合に診断結果をリセット
			if(!recodeChk) {
				mDao.deleteResultList();
			}

			//診断結果の取得
			result = mDao.makerResult(name);
		} catch(Exception e) {
			e.printStackTrace();
		}

		//診断結果の取得結果による分岐
		if(result != null) {
			request.setAttribute("name", name);
			request.setAttribute("result", result);
			return "maker_result.jsp";
		} else {
			return "maker_error.jsp";
		}

	}

}
