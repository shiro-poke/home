package tool;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;

//共通のコントローラークラス
@WebServlet(urlPatterns= {"*.action"})
public class Controller extends HttpServlet {

	//GET送信時の処理
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	//POST送信時の処理
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//文字コードの設定
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		try {
			//渡されたアクションクラス名を取得
			String path = request.getServletPath().substring(1);
			String name = path.replace(".action", "Action").replace("/", ".");
			Action action = (Action)Class.forName(name).newInstance();

			//アクションクラスの実行
			String url = action.execute(request, response);

			//遷移先がTopページかそれ以外で分岐
			if(url.startsWith("../")) {
				response.sendRedirect(url);
			} else {
				request.getRequestDispatcher(url).forward(request, response);
			}

		} catch(Exception e) {
			e.printStackTrace();
		}

	}

}
