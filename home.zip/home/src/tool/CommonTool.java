package tool;

//各クラス共通で使用する処理をまとめたクラス
public class CommonTool {

	//指定された範囲から乱数を一つ返す
	public static int rangeRandomNumber(int start, int end) {

		//第1引数と第2引数の値の大小を比較(結果により使用する式を決める)
		if(start <= end) {
			return (int)(Math.random() * (end - start + 1) + start);
		} else {
			return (int)(Math.random() * (start - end + 1) + end);
		}

	}

}
