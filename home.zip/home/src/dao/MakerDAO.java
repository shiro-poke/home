package dao;

import static tool.CommonTool.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

//異世界診断メーカーのDAOクラス
public class MakerDAO extends DAO {

	//診断メーカーの結果を返す(このメソッドを基準として各処理を行わせる)
	public String makerResult(String name) throws Exception {
		//診断メーカー結果格納用変数
		String result = null;

		//同じ名前の診断結果がある場合、その診断結果を取得
		result = checkInsertName(name);

		//同じ名前の診断結果がない場合に以下を実行
		if(result == null) {
			//前文と後文のリストの取得
			List<String> startList = startMakerList();
			List<String> endList = endMakerList();

			//診断結果の前文と後文を取得
			int startNum = 0;
			int endNum = startList.size() - 1;
			String startText = startList.get(rangeRandomNumber(startNum, endNum));
			endNum = endList.size() - 1;
			String endText = endList.get(rangeRandomNumber(startNum, endNum));

			//診断結果をリストに登録
			boolean updateChk = updateMakerResult(name, startText + endText);

			//診断結果登録の成功確認
			if(updateChk) {
				result = startText + endText;
			}

		}

		return result;
	}

	//同じ名前の診断結果の有無確認(ない場合はnullを返す)
	private String checkInsertName(String name) throws Exception {
		//検索結果格納用変数
		String result = null;

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(指定した名前の診断結果を検索)
		String sql = "select * from maker_result_save where name = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, name);
		ResultSet rs = ps.executeQuery();

		//検索結果がある場合に以下処理を実行
		if(rs.next()) {
			result = rs.getString(2);
		}

		//クローズ処理
		ps.close();
		con.close();

		return result;
	}

	//診断メーカー前文リストの取得
	private List<String> startMakerList() throws Exception {
		//処理結果格納用リスト
		List<String> list = new LinkedList<String>();

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(診断メーカー前文すべての検索)
		String sql = "select * from maker_start_list";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		//検索結果をリストに格納
		while(rs.next()) {
			list.add(rs.getString(2));
		}

		//クローズ処理
		ps.close();
		con.close();

		return list;
	}

	//診断メーカー後文リストの取得
	private List<String> endMakerList() throws Exception {
		//処理結果格納用リスト
		List<String> list = new LinkedList<String>();

		//コネクションの取得
		Connection con = getConnection();

		//SQL文の実行(診断メーカー後文すべての検索)
		String sql = "select * from maker_end_list";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		//検索結果をリストに格納
		while(rs.next()) {
			list.add(rs.getString(2));
		}

		//クローズ処理
		ps.close();
		con.close();

		return list;
	}

	//新規診断結果を登録
	private boolean updateMakerResult(String name, String text) throws Exception {
		//処理正常終了判定用変数
		boolean check = false;

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//SQL文の実行(診断結果の登録)
		String sql = "insert into maker_result_save (name, maker_result) values (?, ?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, name);
		ps.setString(2, text);
		int resultChk = ps.executeUpdate();

		//登録の成功確認(成功時にコミット、失敗時にロールバック)
		if(resultChk > 0) {
			con.commit();
			check = true;
		} else {
			con.rollback();
		}

		//オートコミットの無効解除
		con.setAutoCommit(true);

		//クローズ処理
		ps.close();
		con.close();

		return check;
	}

	//診断結果リストのリセット
	public boolean deleteResultList() throws Exception {
		//処理正常終了判定用変数
		boolean check = false;

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//SQL文の実行(診断結果リストのデータ削除)
		String sql = "delete from maker_result_save";
		PreparedStatement ps = con.prepareStatement(sql);
		int resultChk = ps.executeUpdate();

		//登録の成功確認(成功時にコミット、失敗時にロールバック)
		if(resultChk > 0) {
			con.commit();
			check = true;
		} else {
			con.rollback();
		}

		//オートコミットの無効解除
		con.setAutoCommit(true);

		//クローズ処理
		ps.close();
		con.close();

		return check;
	}

}
