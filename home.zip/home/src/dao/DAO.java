package dao;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

//各DAOクラスのスーパークラス
public class DAO {
	static DataSource ds;

	//コネクションの取得
	public Connection getConnection() throws Exception {

		//データベースへの接続有無による分岐(ない場合に以下処理を行う)
		if(ds == null) {
			//データソースの取得
			InitialContext ic = new InitialContext();
			ds = (DataSource)ic.lookup("java:/comp/env/jdbc/home");
		}

		return ds.getConnection();
	}

}
