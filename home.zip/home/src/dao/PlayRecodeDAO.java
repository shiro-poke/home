package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

//最終プレイ日時を管理するDAOクラス
public class PlayRecodeDAO extends DAO {

	//最終プレイ日の確認(今日が最終プレイ日の場合にtrueを返す)
	public boolean checkDate() throws Exception {
		//最終プレイ日判定用変数
		boolean check = false;

		//コネクションの取得
		Connection con = getConnection();

		//今日の日付を取得
		LocalDate today = LocalDate.now();

		//SQL文の実行(最終プレイ日の取得)
		String sql = "select * from play_recode_date";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		//最終プレイ日の有無で分岐
		if(rs.next()) {
			//最終プレイ日の取得
			LocalDate playDate = rs.getDate(1).toLocalDate();

			//クローズ処理
			ps.close();
			con.close();

			//最終プレイ日が今日じゃない場合に最終プレイ日を更新
			if(today.isAfter(playDate)) {
				updateDate(today);
			} else {
				check = true;
			}

		} else {
			//クローズ処理
			ps.close();
			con.close();

			//最終更新日を登録
			insertDate(today);
		}

		return check;
	}

	//最終プレイ日の登録
	private boolean insertDate(LocalDate day) throws Exception {
		//処理正常終了判定用変数
		boolean check = false;

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//SQL文の実行(最終プレイ日の登録)
		String sql = "insert into play_recode_date (play_date) value (?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setDate(1, Date.valueOf(day));
		int resultChk = ps.executeUpdate();

		//登録の成功確認(成功時にコミット、失敗時にロールバック)
		if(resultChk > 0) {
			con.commit();
			check = true;
		} else {
			con.rollback();
		}

		//オートコミットの無効解除
		con.setAutoCommit(true);

		//クローズ処理
		ps.close();
		con.close();

		return check;
	}

	//最終プレイ日の更新
	private boolean updateDate(LocalDate day) throws Exception {
		//処理正常終了判定用変数
		boolean check = false;

		//コネクションの取得
		Connection con = getConnection();

		//オートコミットの無効
		con.setAutoCommit(false);

		//SQL文の実行(最終プレイ日の更新)
		String sql = "update play_recode_date set play_date = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setDate(1, Date.valueOf(day));
		int resultChk = ps.executeUpdate();

		//更新の成功確認(成功時にコミット、失敗時にロールバック)
		if(resultChk > 0) {
			con.commit();
			check = true;
		} else {
			con.rollback();
		}

		//オートコミットの無効解除
		con.setAutoCommit(true);

		//クローズ処理
		ps.close();
		con.close();

		return check;
	}

}
